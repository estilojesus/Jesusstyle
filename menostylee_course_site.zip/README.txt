Menostylee Guitar Masterclass — Static Site Demo
===============================================

What's included:
- index.html
- styles.css
- script.js
- hero-placeholder.jpg  (SVG placeholder — replace with approved image/video)

Notes:
- This is a static landing page demo. Replace placeholder images and any mention of Menostylee with approved legal copy if you do not have permission.
- To accept payments and host course videos, connect a provider (Stripe, PayPal) or use a course platform (Kajabi, Teachable) and integrate the enrollment flow.
- To host: you can deploy this folder to GitHub Pages, Netlify, Vercel, or any static host.

Quick deploy to GitHub Pages:
1. Create a new GitHub repo and push this folder as the repo root.
2. In repo settings -> Pages, serve from 'main' branch / root.
3. Your site will be available at https://<username>.github.io/<repo> within minutes.

Quick deploy to Netlify:
1. Sign in to Netlify, click 'Add new site' -> 'Deploy manually' -> drag & drop the folder.
2. Or connect your GitHub repo and enable continuous deploy.

If you'd like, I can:
- Customize copy and images for you
- Wire up a payments stub (Stripe Checkout) to the enroll button
- Build the member area with simple auth (Netlify Identity / Firebase Auth)
- Create course pages and lesson templates
