document.getElementById('year').textContent = new Date().getFullYear();

function handleForm(e){
  e.preventDefault();
  const form = e.target;
  const data = {
    name: form.name.value,
    email: form.email.value,
    plan: form.plan.value
  };
  alert('Demo form submitted:\n' + JSON.stringify(data, null, 2) + '\nThis is a demo. Connect a real payment/provider to accept enrollments.');
  form.reset();
}
